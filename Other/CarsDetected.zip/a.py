import cv2 as cv
video = cv.VideoCapture("a.mp4")
car_cascade = cv.CascadeClassifier('cars.xml')
while True:
    check, frame = video.read()
    frame = cv.resize(frame, (640,480))
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    cars = car_cascade.detectMultiScale(gray,1.1,3)
    for(x,y,w,h) in cars:
        cv.rectangle(frame, (x, y), (x+w, y+h), (255, 255, 255),-1)
    cv.imshow("video",frame)
    k = cv.waitKey(5) & 0xFF
    if k == 27:
        break
cv.destroyAllWindows()
video.release()